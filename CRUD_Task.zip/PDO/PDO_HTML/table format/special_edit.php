<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Edit</h2>
    <label for="name">Name:</label>
    <input id="name" type="text" value="john due">
    <br>
    <div>
        <button>Edit</button>
    </div>
</body>
</html>