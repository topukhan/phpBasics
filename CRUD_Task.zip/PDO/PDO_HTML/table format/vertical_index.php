<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <div>
        <h2>Player Lists</h2>


        

       <div>
        <button>Filter</button>
       </div>
       <br>
        <div>
            <button><a href="create.html">create</a></button>
        </div>
    </div>
    <br>
    


    <table border="2">
        <tr>
            <td>

            </td>
            <td>

            </td>
            <td>
                <input id="search" type="text" value="" placeholder="search"> <button> &#8691;</button>
            </td>
            <td>

            </td>
        </tr>
        
        <tr>
        
            <th><input type="checkbox"></th>
            <th>Serial</th>
            <th>Name</th>
            <th>Action</th>
        </tr>


        <tr>
            <td><input type="checkbox"></td>
            <td>1</td>
            <td>Mahmudullah</td>
            <td><button><a href="vertical_show.html" type="button">Show</a></button>
                <button><a href="vertical_edit.html">Edit</a></button>
                <button>Delete</button>
                <button>Share</button>
                
            </td>
        </tr>


        <tr>
            <td><input type="checkbox"></td>
            <td>2</td>
            <td>Mashrafee</td>
            <td><button><a href="vertical_show.html" type="button">Show</a></button>
                <button><a href="vertical_edit.html">Edit</a></button>
                <button>Delete</button>
                <button>Share</button>
               
            </td>
        </tr>


    </table>
    <br>
    <div>
        <span>Rover per page</span>
    <select>
        <option>1</option>
        <option>2</option>
        <option>3</option>
        <option>4</option>
        <option>5</option>
        <option>6</option>
        <option>7</option>
        <option>8</option>
        <option>9</option>
        <option>10</option>
    </select>
    </div>
    <br>
       <div>
        <button><</button>
        <button>1</button>
        <button>2</button>
        <button>3</button>
        <button>></button>
       </div>
       <br>
           <div>
            <button>PDF</button>
           </div><br>
           <div> <button>Excel</button></div><br>
           <div> <button>Email</button></div><br>
           <div> <button>MS Word</button></div><br>
           <div> <button>History</button></div><br>
          <div>  <button>Print</button>
          </div>
</body>

</html>