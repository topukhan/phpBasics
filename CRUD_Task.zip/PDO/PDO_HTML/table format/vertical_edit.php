<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>Edit</h2>
    <div><label for="name">Name:</label></div>
    <br>
   <div> <input id="name" type="text" value="john due"></div>
   <br>
    <button>Edit</button>
</body>
</html>